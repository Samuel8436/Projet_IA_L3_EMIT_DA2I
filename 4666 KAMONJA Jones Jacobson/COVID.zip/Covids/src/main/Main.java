/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.io.FileWriter;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;
import org.jpl7.Query;
import org.jpl7.Term;
import org.jpl7.Variable;

/**
 *
 * @author ANJARAHASINA
 */
public class Main extends javax.swing.JFrame {

    /**
     * Creates new form Main
     */
    public Main() {
        initComponents();
        panel_bouton.setVisible(false);
        btnAnalyser.setVisible(false);
        jLabel24.setVisible(false);
        lbl_res.setVisible(false);

    }
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        fievre = new javax.swing.ButtonGroup();
        odeur = new javax.swing.ButtonGroup();
        toux = new javax.swing.ButtonGroup();
        gout = new javax.swing.ButtonGroup();
        fatigue = new javax.swing.ButtonGroup();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jtab = new javax.swing.JTabbedPane();
        jtab0 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        btn_effacer_faits = new javax.swing.JButton();
        btnAnalyser = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        aff_faits = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txt_temp = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_nom = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        fievre_oui = new javax.swing.JRadioButton();
        fievre_non = new javax.swing.JRadioButton();
        fatigue_oui = new javax.swing.JRadioButton();
        fatigue_non = new javax.swing.JRadioButton();
        toux_oui = new javax.swing.JRadioButton();
        toux_non = new javax.swing.JRadioButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        odeur_oui = new javax.swing.JRadioButton();
        odeur_non = new javax.swing.JRadioButton();
        gout_oui = new javax.swing.JRadioButton();
        gout_non = new javax.swing.JRadioButton();
        panel_bouton = new javax.swing.JPanel();
        btn_arbre = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        background1 = new img.Background();
        jLabel24 = new javax.swing.JLabel();
        lbl_res = new javax.swing.JLabel();
        btn_valider = new javax.swing.JButton();
        jtab1 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txt_prolog = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        btnResultat_fich = new javax.swing.JButton();
        btnArbre2 = new javax.swing.JButton();
        jtab2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jtab3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_faits = new javax.swing.JTextArea();
        jtab4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table_liste = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        btnRech = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(java.awt.SystemColor.windowBorder);
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(java.awt.SystemColor.controlShadow);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("-");
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, 30, 26));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 102));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("X");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 0, 30, 26));

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(java.awt.SystemColor.control);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("TEST COVID");
        jLabel1.setOpaque(true);
        jLabel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel1MouseDragged(evt);
            }
        });
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 3, 850, 26));

        jtab.setBackground(java.awt.SystemColor.windowBorder);
        jtab.setTabPlacement(javax.swing.JTabbedPane.RIGHT);
        jtab.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jtab.setOpaque(true);

        jtab0.setBackground(new java.awt.Color(153, 153, 255));
        jtab0.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_effacer_faits.setBackground(java.awt.SystemColor.windowBorder);
        btn_effacer_faits.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_effacer_faits.setForeground(java.awt.SystemColor.control);
        btn_effacer_faits.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_refresh_18px.png"))); // NOI18N
        btn_effacer_faits.setBorderPainted(false);
        btn_effacer_faits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_effacer_faitsActionPerformed(evt);
            }
        });
        jPanel4.add(btn_effacer_faits, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 250, 40, 30));

        btnAnalyser.setBackground(java.awt.SystemColor.windowBorder);
        btnAnalyser.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnAnalyser.setForeground(java.awt.SystemColor.control);
        btnAnalyser.setText("Diagnostic");
        btnAnalyser.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.SystemColor.control));
        btnAnalyser.setBorderPainted(false);
        btnAnalyser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAnalyser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalyserActionPerformed(evt);
            }
        });
        jPanel4.add(btnAnalyser, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 120, 30));

        aff_faits.setEditable(false);
        aff_faits.setBackground(java.awt.SystemColor.windowBorder);
        aff_faits.setColumns(20);
        aff_faits.setForeground(java.awt.SystemColor.control);
        aff_faits.setRows(5);
        jScrollPane2.setViewportView(aff_faits);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 360, 220));

        jtab0.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 380, 340));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Gadugi", 1, 11)); // NOI18N
        jLabel5.setForeground(java.awt.SystemColor.control);
        jLabel5.setText("°C");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 30, 20));

        txt_temp.setBackground(new java.awt.Color(153, 153, 153));
        txt_temp.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        txt_temp.setForeground(java.awt.SystemColor.control);
        txt_temp.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_temp.setOpaque(false);
        txt_temp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_tempKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_tempKeyTyped(evt);
            }
        });
        jPanel2.add(txt_temp, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 120, 20));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(java.awt.SystemColor.control);
        jLabel6.setText("Nom du patient :");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, 20));

        txt_nom.setBackground(new java.awt.Color(153, 153, 153));
        txt_nom.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        txt_nom.setForeground(java.awt.SystemColor.control);
        txt_nom.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_nom.setOpaque(false);
        jPanel2.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 210, 20));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(java.awt.SystemColor.control);
        jLabel8.setText("Temperature :");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, 20));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(java.awt.SystemColor.control);
        jLabel9.setText("Toux : ");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, -1, 20));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setForeground(java.awt.SystemColor.control);
        jLabel11.setText("Fièvre :");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, -1, 20));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(java.awt.SystemColor.control);
        jLabel15.setText("Sentir le goût :");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, 20));

        fievre_oui.setBackground(new java.awt.Color(153, 153, 153));
        fievre.add(fievre_oui);
        fievre_oui.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        fievre_oui.setForeground(java.awt.SystemColor.control);
        fievre_oui.setText("OUI");
        jPanel2.add(fievre_oui, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, -1, -1));

        fievre_non.setBackground(new java.awt.Color(153, 153, 153));
        fievre.add(fievre_non);
        fievre_non.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        fievre_non.setForeground(java.awt.SystemColor.control);
        fievre_non.setSelected(true);
        fievre_non.setText("NON");
        jPanel2.add(fievre_non, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, -1, -1));

        fatigue_oui.setBackground(new java.awt.Color(153, 153, 153));
        fatigue.add(fatigue_oui);
        fatigue_oui.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        fatigue_oui.setForeground(java.awt.SystemColor.control);
        fatigue_oui.setText("OUI");
        jPanel2.add(fatigue_oui, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, -1, -1));

        fatigue_non.setBackground(new java.awt.Color(153, 153, 153));
        fatigue.add(fatigue_non);
        fatigue_non.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        fatigue_non.setForeground(java.awt.SystemColor.control);
        fatigue_non.setSelected(true);
        fatigue_non.setText("NON");
        jPanel2.add(fatigue_non, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, -1, -1));

        toux_oui.setBackground(new java.awt.Color(153, 153, 153));
        toux.add(toux_oui);
        toux_oui.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        toux_oui.setForeground(java.awt.SystemColor.control);
        toux_oui.setText("OUI");
        toux_oui.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                toux_ouiMouseClicked(evt);
            }
        });
        jPanel2.add(toux_oui, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, -1, -1));

        toux_non.setBackground(new java.awt.Color(153, 153, 153));
        toux.add(toux_non);
        toux_non.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        toux_non.setForeground(java.awt.SystemColor.control);
        toux_non.setSelected(true);
        toux_non.setText("NON");
        jPanel2.add(toux_non, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setForeground(java.awt.SystemColor.control);
        jLabel16.setText("Fatigue Génerale : ");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, 20));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setForeground(java.awt.SystemColor.control);
        jLabel19.setText("Sentir l'ordeur :");
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, -1, 20));

        odeur_oui.setBackground(new java.awt.Color(153, 153, 153));
        odeur.add(odeur_oui);
        odeur_oui.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        odeur_oui.setForeground(java.awt.SystemColor.control);
        odeur_oui.setSelected(true);
        odeur_oui.setText("OUI");
        jPanel2.add(odeur_oui, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, -1, -1));

        odeur_non.setBackground(new java.awt.Color(153, 153, 153));
        odeur.add(odeur_non);
        odeur_non.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        odeur_non.setForeground(java.awt.SystemColor.control);
        odeur_non.setText("NON");
        jPanel2.add(odeur_non, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, -1, -1));

        gout_oui.setBackground(new java.awt.Color(153, 153, 153));
        gout.add(gout_oui);
        gout_oui.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gout_oui.setForeground(java.awt.SystemColor.control);
        gout_oui.setSelected(true);
        gout_oui.setText("OUI");
        jPanel2.add(gout_oui, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, -1, -1));

        gout_non.setBackground(new java.awt.Color(153, 153, 153));
        gout.add(gout_non);
        gout_non.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        gout_non.setForeground(java.awt.SystemColor.control);
        gout_non.setText("NON");
        jPanel2.add(gout_non, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 200, -1, -1));

        jtab0.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 400, 270));

        panel_bouton.setBackground(new java.awt.Color(102, 102, 102));
        panel_bouton.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_arbre.setBackground(java.awt.SystemColor.controlHighlight);
        btn_arbre.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        btn_arbre.setText("Arbre de recherche");
        btn_arbre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_arbre.setBorderPainted(false);
        btn_arbre.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_arbre.setFocusPainted(false);
        btn_arbre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_arbreActionPerformed(evt);
            }
        });
        panel_bouton.add(btn_arbre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 160, 30));

        jtab0.add(panel_bouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 180, 50));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setForeground(java.awt.SystemColor.control);
        jLabel23.setText("Information sur la personne à tester");
        jtab0.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 230, 30));

        jLabel24.setFont(new java.awt.Font("Gadugi", 1, 11)); // NOI18N
        jLabel24.setForeground(java.awt.SystemColor.control);
        jLabel24.setText("Résultat du test : ");

        lbl_res.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        lbl_res.setForeground(new java.awt.Color(0, 255, 51));
        lbl_res.setText("NEGATIF");

        btn_valider.setBackground(java.awt.SystemColor.controlHighlight);
        btn_valider.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        btn_valider.setText("Valider");
        btn_valider.setBorderPainted(false);
        btn_valider.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_valider.setFocusPainted(false);
        btn_valider.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_validerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout background1Layout = new javax.swing.GroupLayout(background1);
        background1.setLayout(background1Layout);
        background1Layout.setHorizontalGroup(
            background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, background1Layout.createSequentialGroup()
                .addContainerGap(449, Short.MAX_VALUE)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(lbl_res, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(181, 181, 181))
            .addGroup(background1Layout.createSequentialGroup()
                .addGap(195, 195, 195)
                .addComponent(btn_valider, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        background1Layout.setVerticalGroup(
            background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(background1Layout.createSequentialGroup()
                .addContainerGap(346, Short.MAX_VALUE)
                .addComponent(btn_valider, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addGroup(background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_res, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53))
        );

        jtab0.add(background1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 460));

        jtab.addTab("Enquête", jtab0);

        jtab1.setBackground(java.awt.SystemColor.windowBorder);
        jtab1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setForeground(java.awt.SystemColor.control);
        jLabel17.setText("Fichier Prolog");
        jtab1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        jScrollPane6.setFont(new java.awt.Font("High Tower Text", 1, 14)); // NOI18N

        txt_prolog.setColumns(20);
        txt_prolog.setRows(5);
        jScrollPane6.setViewportView(txt_prolog);

        jtab1.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 770, 340));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setText("<---");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.setOpaque(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jtab1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 80, 20));

        btnResultat_fich.setBackground(java.awt.SystemColor.windowBorder);
        btnResultat_fich.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnResultat_fich.setForeground(java.awt.SystemColor.control);
        btnResultat_fich.setText("Resultat ");
        btnResultat_fich.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.SystemColor.control));
        btnResultat_fich.setBorderPainted(false);
        btnResultat_fich.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnResultat_fich.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResultat_fichActionPerformed(evt);
            }
        });
        jtab1.add(btnResultat_fich, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 390, 130, 30));

        btnArbre2.setBackground(java.awt.SystemColor.windowBorder);
        btnArbre2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnArbre2.setForeground(java.awt.SystemColor.control);
        btnArbre2.setText("Arbre prolog");
        btnArbre2.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.SystemColor.control));
        btnArbre2.setBorderPainted(false);
        btnArbre2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnArbre2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArbre2ActionPerformed(evt);
            }
        });
        jtab1.add(btnArbre2, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 390, 130, 30));

        jtab.addTab("Résultat", jtab1);

        jtab2.setBackground(new java.awt.Color(255, 255, 255));
        jtab2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jtab2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("Arbre de recherche");
        jtab2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 200, -1));

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/capture_abre.JPG"))); // NOI18N
        jtab2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 690, 380));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_back_arrow_18px.png"))); // NOI18N
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setOpaque(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jtab2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 80, 30));

        jtab.addTab("Lieu&date", jtab2);

        jtab3.setBackground(java.awt.SystemColor.windowBorder);
        jtab3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(java.awt.SystemColor.windowBorder);
        jScrollPane1.setBorder(null);
        jScrollPane1.setForeground(java.awt.SystemColor.control);

        txt_faits.setColumns(20);
        txt_faits.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_faits.setRows(5);
        jScrollPane1.setViewportView(txt_faits);

        jtab3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 770, 320));

        jtab.addTab("tab5", jtab3);

        jtab4.setBackground(java.awt.SystemColor.windowBorder);
        jtab4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table_liste.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        table_liste.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Numéro", "Nom de la personne", "Date du test", "Resultat"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table_liste.setName(""); // NOI18N
        table_liste.setOpaque(false);
        table_liste.setRowHeight(20);
        table_liste.setShowHorizontalLines(false);
        table_liste.setShowVerticalLines(false);
        jScrollPane3.setViewportView(table_liste);

        jtab4.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 780, 250));

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        jLabel7.setForeground(java.awt.SystemColor.control);
        jLabel7.setText("Date du test");
        jtab4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 20, -1, -1));

        btnRech.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_search_14px.png"))); // NOI18N
        btnRech.setBorderPainted(false);
        btnRech.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRech.setFocusPainted(false);
        btnRech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechActionPerformed(evt);
            }
        });
        jtab4.add(btnRech, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 20, 40, 20));

        jButton6.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_back_arrow_18px.png"))); // NOI18N
        jButton6.setText("Retour au test");
        jButton6.setBorderPainted(false);
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.setFocusPainted(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jtab4.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 160, -1));

        jButton8.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tree.png"))); // NOI18N
        jButton8.setText("Arbre de recherche");
        jButton8.setBorderPainted(false);
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.setFocusPainted(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jtab4.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 350, 190, -1));

        jLabel26.setFont(new java.awt.Font("Gadugi", 1, 12)); // NOI18N
        jLabel26.setForeground(java.awt.SystemColor.control);
        jLabel26.setText("Liste des tests enregistré");
        jtab4.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, -1, -1));

        jtab.addTab("tab6", jtab4);

        jPanel1.add(jtab, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 33, 990, 430));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 851, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    int xMouse,yMouse;
    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened

    }//GEN-LAST:event_formWindowOpened

    private void rech_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rech_dateMouseClicked

    }//GEN-LAST:event_rech_dateMouseClicked

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_jLabel1MousePressed

    private void jLabel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseDragged
        this.setLocation(evt.getXOnScreen()-xMouse, evt.getYOnScreen()-yMouse);
    }//GEN-LAST:event_jLabel1MouseDragged

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        this.setExtendedState(Main.ICONIFIED);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jtab.setSelectedIndex(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnArbre2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArbre2ActionPerformed
        jtab.setSelectedIndex(2);
    }//GEN-LAST:event_btnArbre2ActionPerformed

    private void btnResultat_fichActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResultat_fichActionPerformed
        jtab.setSelectedIndex(2);
    }//GEN-LAST:event_btnResultat_fichActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jtab.setSelectedIndex(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void btn_arbreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_arbreActionPerformed
        jtab.setSelectedIndex(2);
    }//GEN-LAST:event_btn_arbreActionPerformed

    private void btn_validerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_validerActionPerformed
        String name = txt_nom.getText();
        String temp = txt_temp.getText();
        if(name.isEmpty() || temp.isEmpty()){
            JOptionPane.showMessageDialog(null,"Tous les champs sont obligatoire","ExpertSystCovid",JOptionPane.INFORMATION_MESSAGE);
        }else{
            Float tp = Float.parseFloat(temp);
            String nom = name.toLowerCase();
            //temperature
            String aff_temp = "La temperature de "+name + " est : "+tp+" °C";
            String temperature = "temperature("+nom+",normal).";
            if(tp>37.8)
            temperature = "temperature("+nom+",eleve).";
            //toux
            String aff_toux = name+" n'a pas du toux";
            String toux = "toux(-).";
            if(toux_oui.isSelected()){
                toux = "toux("+nom+").";
                aff_toux = name+" a du toux";
            }

            //fievre
            String aff_fievre = name+" n'a pas du fièvre";
            String fievre = "fievre().";
            if(fievre_oui.isSelected())
            {
                fievre ="fievre("+nom+").";
                aff_fievre = name+" a du fièvre";
            }

            if(fievre_non.isSelected())
            fievre = "fievre(-).";
            //fatigue
            String aff_fatigue = name+" n'a pas de fatigue";
            String fatigue = "fatigue().";
            if(fatigue_oui.isSelected())
            {
                fatigue = "fatigue("+nom+").";
                aff_fatigue = name+" a de la fatigue";
            }

            if(fatigue_non.isSelected())
            fatigue = "fatigue(-).";
            //odeur
            String aff_odeur = name+" sent bien l'odeur";
            String odeur = "sentir_odeur("+nom+",non).";
            if(odeur_oui.isSelected())
            odeur = "sentir_odeur("+nom+",oui).";
            if(odeur_non.isSelected())
            {
                odeur = "sentir_odeur("+nom+",non).";
                aff_odeur = name+" ne sent pas l'odeur";
            }

            //gout
            String aff_gout = name+" sent bien le goût des choses";
            String gout = "sentir_gout("+nom+",non).";
            if(gout_oui.isSelected())
            gout = "sentir_gout("+nom+",oui).";
            if(gout_non.isSelected())
            {
                gout = "sentir_gout("+nom+",non).";
                aff_gout = name+" ne sent pas le goût des choses";
            }

            String affichage_fait = aff_temp+"\n"+aff_toux+"\n"+aff_fievre+"\n"+aff_fatigue+"\n"+aff_odeur+"\n"+aff_gout;
            String faits = temperature+"\n"+toux+"\n"+fievre+"\n"+fatigue+"\n"+odeur+"\n"+gout+"\n";
            String rg =  "positif(X):-(temperature(X,eleve),toux(X),fievre(X),fatigue(X));(sentir_odeur(X,non),sentir_gout(X,non)).";
            txt_faits.setText(faits+"\n"+rg);
            aff_faits.setText(affichage_fait);
            btnAnalyser.setVisible(true);
            panel_bouton.setVisible(true);

        }
    }//GEN-LAST:event_btn_validerActionPerformed

    private void toux_ouiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_toux_ouiMouseClicked

    }//GEN-LAST:event_toux_ouiMouseClicked

    private void txt_tempKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_tempKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || (c==KeyEvent.VK_DELETE))){
            evt.consume();
        }
    }//GEN-LAST:event_txt_tempKeyTyped

    private void txt_tempKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_tempKeyReleased
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || (c==KeyEvent.VK_DELETE))){
            evt.consume();
        }
    }//GEN-LAST:event_txt_tempKeyReleased

    private void btnAnalyserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalyserActionPerformed

        try{

            FileWriter fichier = new FileWriter("pl.pl");
            fichier.write(txt_faits.getText());
            fichier.close();

            Query q = new Query("consult('pl.pl')");
            q.hasSolution();
            Variable X = new Variable("X");
            Query q1 = new Query("positif",new Term[]{X});
            Map<String, Term>res;
            res = q1.oneSolution();
            String resultat = "NEGATIF";
            if(q1.hasSolution())
            {
                resultat = "POSITIF";
            }
            if(resultat == "NEGATIF"){
                lbl_res.setForeground(Color.green);
            }else{
                lbl_res.setForeground(new Color(255,102,102));
            }
            lbl_res.setText(resultat);
            jLabel24.setVisible(true);
            lbl_res.setVisible(true);

            //jtab.setSelectedIndex(2);
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnAnalyserActionPerformed

    private void btn_effacer_faitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_effacer_faitsActionPerformed
        txt_faits.setText("");
        aff_faits.setText("");
        btnAnalyser.setVisible(false);
        jLabel24.setVisible(false);
        lbl_res.setVisible(false);
        txt_nom.setText("");
        txt_temp.setText("");
    }//GEN-LAST:event_btn_effacer_faitsActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        jtab.setSelectedIndex(2);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        jtab.setSelectedIndex(0);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void btnRechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechActionPerformed

    }//GEN-LAST:event_btnRechActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws UnsupportedLookAndFeelException {
        UIManager.setLookAndFeel(new NimbusLookAndFeel());
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea aff_faits;
    private img.Background background1;
    private javax.swing.JButton btnAnalyser;
    private javax.swing.JButton btnArbre2;
    private javax.swing.JButton btnRech;
    private javax.swing.JButton btnResultat_fich;
    private javax.swing.JButton btn_arbre;
    private javax.swing.JButton btn_effacer_faits;
    private javax.swing.JButton btn_valider;
    private javax.swing.ButtonGroup fatigue;
    private javax.swing.JRadioButton fatigue_non;
    private javax.swing.JRadioButton fatigue_oui;
    private javax.swing.ButtonGroup fievre;
    private javax.swing.JRadioButton fievre_non;
    private javax.swing.JRadioButton fievre_oui;
    private javax.swing.ButtonGroup gout;
    private javax.swing.JRadioButton gout_non;
    private javax.swing.JRadioButton gout_oui;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jtab;
    private javax.swing.JPanel jtab0;
    private javax.swing.JPanel jtab1;
    private javax.swing.JPanel jtab2;
    private javax.swing.JPanel jtab3;
    private javax.swing.JPanel jtab4;
    private javax.swing.JLabel lbl_res;
    private javax.swing.ButtonGroup odeur;
    private javax.swing.JRadioButton odeur_non;
    private javax.swing.JRadioButton odeur_oui;
    private javax.swing.JPanel panel_bouton;
    private javax.swing.JTable table_liste;
    private javax.swing.ButtonGroup toux;
    private javax.swing.JRadioButton toux_non;
    private javax.swing.JRadioButton toux_oui;
    public javax.swing.JTextArea txt_faits;
    private javax.swing.JTextField txt_nom;
    private javax.swing.JTextArea txt_prolog;
    private javax.swing.JTextField txt_temp;
    // End of variables declaration//GEN-END:variables
}

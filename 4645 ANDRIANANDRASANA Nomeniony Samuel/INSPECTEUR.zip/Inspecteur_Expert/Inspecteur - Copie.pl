setrouve(ze,ez,02 11 2023). 
jaloux(ze,nj). 
sansargent(ze).
suspect(X):-setrouve(X,hjhjk,01 11 2023),(jaloux(X,ze);sansargent(X)).
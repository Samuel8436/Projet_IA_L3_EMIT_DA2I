setrouve(rabe,andrainjato,01 11 2023). 
jaloux(rabe,rakoto). 
 suspect(X):-setrouve(X,ivory,01 11 2023),jaloux(X,rakoto).
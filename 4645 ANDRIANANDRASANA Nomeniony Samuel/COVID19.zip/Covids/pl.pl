temperature(parfait,eleve).
toux(parfait).
fievre(parfait).
fatigue(parfait).
sentir_odeur(parfait,oui).
sentir_gout(parfait,oui).

positif(X):-(temperature(X,eleve),toux(X),fievre(X),fatigue(X));(sentir_odeur(X,non),sentir_gout(X,non)).
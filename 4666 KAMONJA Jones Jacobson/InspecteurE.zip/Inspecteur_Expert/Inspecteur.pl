setrouve(erick,emit,02 11 2023). 
jaloux(erick,jones). 
sansargent(erick).
suspect(X):-setrouve(X,emit,02 11 2023),(jaloux(X,jones);sansargent(X)).
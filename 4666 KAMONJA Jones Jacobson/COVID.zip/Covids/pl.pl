temperature(tahina,normal).
toux(-).
fievre(tahina).
fatigue(-).
sentir_odeur(tahina,oui).
sentir_gout(tahina,non).

positif(X):-(temperature(X,eleve),toux(X),fievre(X),fatigue(X));(sentir_odeur(X,non),sentir_gout(X,non)).